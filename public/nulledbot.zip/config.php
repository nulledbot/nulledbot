<?php
$nulledbot_api_key = 'PASTEAPIKEYHERE'; // REQUIRED, PASTE YOUR API KEY HERE
?>
